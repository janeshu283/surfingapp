const express = require('express');
const router = express.Router();
const { createClient } = require('@supabase/supabase-js');

// Supabaseクライアントの初期化
const supabaseUrl = process.env.SUPABASE_URL || 'https://your-supabase-url.supabase.co';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY || 'your-supabase-service-key';
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// すべてのサーフスポットを取得
router.get('/', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('surf_spots')
      .select('*');
    
    if (error) throw error;
    
    res.json(data);
  } catch (err) {
    console.error('サーフスポット取得エラー:', err);
    res.status(500).json({ error: 'サーフスポットの取得に失敗しました' });
  }
});

// IDによるサーフスポットの取得
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { data, error } = await supabase
      .from('surf_spots')
      .select('*, regions(*), live_cameras(*)')
      .eq('id', id)
      .single();
    
    if (error) throw error;
    
    if (!data) {
      return res.status(404).json({ error: 'サーフスポットが見つかりません' });
    }
    
    res.json(data);
  } catch (err) {
    console.error('サーフスポット詳細取得エラー:', err);
    res.status(500).json({ error: 'サーフスポットの詳細取得に失敗しました' });
  }
});

module.exports = router;
