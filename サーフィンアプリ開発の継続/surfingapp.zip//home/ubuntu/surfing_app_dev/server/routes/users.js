const express = require('express');
const router = express.Router();
const { createClient } = require('@supabase/supabase-js');

// Supabaseクライアントの初期化
const supabaseUrl = process.env.SUPABASE_URL || 'https://your-supabase-url.supabase.co';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY || 'your-supabase-service-key';
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// ユーザープロフィールの取得
router.get('/profile/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error) throw error;
    
    if (!data) {
      return res.status(404).json({ error: 'プロフィールが見つかりません' });
    }
    
    res.json(data);
  } catch (err) {
    console.error('プロフィール取得エラー:', err);
    res.status(500).json({ error: 'プロフィールの取得に失敗しました' });
  }
});

// ユーザープロフィールの更新
router.put('/profile/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { username, skill_level, board_type, board_length, preferred_style } = req.body;
    
    // 更新データの検証
    if (!username || !skill_level || !board_type) {
      return res.status(400).json({ error: '必須フィールドが不足しています' });
    }
    
    // プロフィールの更新
    const { data, error } = await supabase
      .from('profiles')
      .update({
        username,
        skill_level,
        board_type,
        board_length: board_length || null,
        preferred_style: preferred_style || null,
        updated_at: new Date()
      })
      .eq('id', userId)
      .select()
      .single();
    
    if (error) throw error;
    
    res.json(data);
  } catch (err) {
    console.error('プロフィール更新エラー:', err);
    res.status(500).json({ error: 'プロフィールの更新に失敗しました' });
  }
});

// コミュニティ投稿の取得
router.get('/posts', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('posts')
      .select('*, users(id, username), surf_spots(id, name)')
      .order('created_at', { ascending: false })
      .limit(20);
    
    if (error) throw error;
    
    res.json(data);
  } catch (err) {
    console.error('投稿取得エラー:', err);
    res.status(500).json({ error: '投稿の取得に失敗しました' });
  }
});

// 新規投稿の作成
router.post('/posts', async (req, res) => {
  try {
    const { user_id, surf_spot_id, content, wave_height, wave_quality, crowd_level } = req.body;
    
    // 投稿データの検証
    if (!user_id || !surf_spot_id || !content) {
      return res.status(400).json({ error: '必須フィールドが不足しています' });
    }
    
    // 投稿の作成
    const { data, error } = await supabase
      .from('posts')
      .insert({
        user_id,
        surf_spot_id,
        content,
        wave_height: wave_height || null,
        wave_quality: wave_quality || null,
        crowd_level: crowd_level || null,
        created_at: new Date()
      })
      .select()
      .single();
    
    if (error) throw error;
    
    res.status(201).json(data);
  } catch (err) {
    console.error('投稿作成エラー:', err);
    res.status(500).json({ error: '投稿の作成に失敗しました' });
  }
});

module.exports = router;
