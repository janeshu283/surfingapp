const express = require('express');
const router = express.Router();
const { createClient } = require('@supabase/supabase-js');

// Supabaseクライアントの初期化
const supabaseUrl = process.env.SUPABASE_URL || 'https://your-supabase-url.supabase.co';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY || 'your-supabase-service-key';
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// 特定のサーフスポットの波予測を取得
router.get('/spot/:spotId', async (req, res) => {
  try {
    const { spotId } = req.params;
    const { data, error } = await supabase
      .from('wave_forecasts')
      .select('*')
      .eq('surf_spot_id', spotId)
      .order('forecast_time', { ascending: true });
    
    if (error) throw error;
    
    res.json(data);
  } catch (err) {
    console.error('波予測取得エラー:', err);
    res.status(500).json({ error: '波予測の取得に失敗しました' });
  }
});

// パーソナライズされたスコアを取得
router.get('/personalized', async (req, res) => {
  try {
    const { spotId, skillLevel, boardType } = req.query;
    
    if (!spotId || !skillLevel) {
      return res.status(400).json({ error: '必須パラメータが不足しています' });
    }
    
    let query = supabase
      .from('personalized_scores')
      .select('*')
      .eq('surf_spot_id', spotId)
      .eq('skill_level', skillLevel);
    
    if (boardType) {
      query = query.eq('board_type', boardType);
    }
    
    const { data, error } = await query.order('forecast_time', { ascending: true });
    
    if (error) throw error;
    
    res.json(data);
  } catch (err) {
    console.error('パーソナライズスコア取得エラー:', err);
    res.status(500).json({ error: 'パーソナライズスコアの取得に失敗しました' });
  }
});

module.exports = router;
