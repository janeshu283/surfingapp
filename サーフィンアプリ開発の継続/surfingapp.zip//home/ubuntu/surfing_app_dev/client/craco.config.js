module.exports = {
  webpack: {
    configure: (webpackConfig) => {
      // ビルド設定の最適化
      webpackConfig.optimization = {
        ...webpackConfig.optimization,
        splitChunks: {
          chunks: 'all',
          name: false,
        },
      };
      
      // ソースマップの設定
      webpackConfig.devtool = process.env.NODE_ENV === 'production' 
        ? false 
        : 'source-map';
      
      return webpackConfig;
    },
  },
  // 環境変数の設定
  env: {
    REACT_APP_VERSION: process.env.npm_package_version,
  },
  // 出力パスの設定
  paths: {
    appBuild: 'build',
  },
};
