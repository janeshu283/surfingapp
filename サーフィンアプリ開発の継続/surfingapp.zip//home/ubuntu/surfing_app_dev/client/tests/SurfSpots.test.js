import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import '@testing-library/jest-dom';
import SurfSpots from '../src/pages/SurfSpots';

// モックの設定
jest.mock('../src/services/supabaseClient', () => ({
  from: jest.fn().mockReturnValue({
    select: jest.fn().mockReturnThis(),
    eq: jest.fn().mockReturnThis(),
    order: jest.fn().mockImplementation(() => {
      return {
        data: [
          {
            id: 1,
            name: 'テストスポット1',
            regions: { prefecture: '千葉県', name: '九十九里' },
            difficulty: 'beginner',
            description: 'テスト用のサーフスポットです'
          },
          {
            id: 2,
            name: 'テストスポット2',
            regions: { prefecture: '神奈川県', name: '湘南' },
            difficulty: 'intermediate',
            description: '中級者向けのサーフスポットです'
          }
        ],
        error: null
      };
    })
  })
}));

// テスト用のラッパーコンポーネント
const renderWithRouter = (ui) => {
  return render(
    <BrowserRouter>
      {ui}
    </BrowserRouter>
  );
};

describe('SurfSpots Component', () => {
  test('renders surf spots page title', () => {
    renderWithRouter(<SurfSpots />);
    expect(screen.getByText('サーフスポット一覧')).toBeInTheDocument();
  });

  test('displays region filter', () => {
    renderWithRouter(<SurfSpots />);
    expect(screen.getByText('地域で絞り込み:')).toBeInTheDocument();
    expect(screen.getByText('すべての地域')).toBeInTheDocument();
  });

  test('displays surf spots when data is loaded', async () => {
    renderWithRouter(<SurfSpots />);
    
    await waitFor(() => {
      expect(screen.getByText('テストスポット1')).toBeInTheDocument();
      expect(screen.getByText('テストスポット2')).toBeInTheDocument();
      expect(screen.getByText('千葉県 - 九十九里')).toBeInTheDocument();
      expect(screen.getByText('神奈川県 - 湘南')).toBeInTheDocument();
    });
  });
});
