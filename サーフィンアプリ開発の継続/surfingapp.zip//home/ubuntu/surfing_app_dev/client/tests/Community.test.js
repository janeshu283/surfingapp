import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import '@testing-library/jest-dom';
import Community from '../src/pages/Community';

// モックの設定
jest.mock('../src/services/supabaseClient', () => ({
  auth: {
    getUser: jest.fn().mockResolvedValue({ data: { user: null } }),
    onAuthStateChange: jest.fn().mockReturnValue({ data: { subscription: { unsubscribe: jest.fn() } } })
  },
  from: jest.fn().mockReturnValue({
    select: jest.fn().mockReturnThis(),
    eq: jest.fn().mockReturnThis(),
    order: jest.fn().mockReturnThis(),
    then: jest.fn().mockImplementation(callback => callback({ data: [], error: null }))
  })
}));

// テスト用のラッパーコンポーネント
const renderWithRouter = (ui) => {
  return render(
    <BrowserRouter>
      {ui}
    </BrowserRouter>
  );
};

describe('Community Component', () => {
  test('renders community page title', () => {
    renderWithRouter(<Community />);
    expect(screen.getByText('コミュニティ')).toBeInTheDocument();
  });

  test('displays login prompt when user is not logged in', async () => {
    renderWithRouter(<Community />);
    await waitFor(() => {
      expect(screen.getByText(/投稿するにはログインしてください/)).toBeInTheDocument();
    });
  });

  test('displays "no posts" message when there are no posts', async () => {
    renderWithRouter(<Community />);
    await waitFor(() => {
      expect(screen.getByText('投稿がありません')).toBeInTheDocument();
    });
  });
});
