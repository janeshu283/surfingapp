import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import '@testing-library/jest-dom';
import SpotDetail from '../src/pages/SpotDetail';

// モックの設定
jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useParams: () => ({ id: '1' })
}));

jest.mock('../src/services/supabaseClient', () => ({
  auth: {
    getUser: jest.fn().mockResolvedValue({ data: { user: null } })
  },
  from: jest.fn().mockReturnValue({
    select: jest.fn().mockReturnThis(),
    eq: jest.fn().mockReturnThis(),
    order: jest.fn().mockReturnThis(),
    single: jest.fn().mockImplementation(() => {
      return {
        data: {
          id: 1,
          name: 'テストスポット',
          regions: { prefecture: '千葉県', name: '九十九里' },
          difficulty: 'beginner',
          description: 'テスト用のサーフスポットです',
          latitude: 35.3789,
          longitude: 140.3908,
          live_cameras: [
            { id: 1, name: 'テストカメラ', youtube_url: 'https://www.youtube.com/watch?v=example' }
          ]
        },
        error: null
      };
    })
  })
}));

// テスト用のラッパーコンポーネント
const renderWithRouter = (ui) => {
  return render(
    <BrowserRouter>
      {ui}
    </BrowserRouter>
  );
};

describe('SpotDetail Component', () => {
  test('renders spot details when data is loaded', async () => {
    renderWithRouter(<SpotDetail />);
    
    await waitFor(() => {
      expect(screen.getByText('テストスポット')).toBeInTheDocument();
      expect(screen.getByText('千葉県 - 九十九里')).toBeInTheDocument();
      expect(screen.getByText('スポット情報')).toBeInTheDocument();
      expect(screen.getByText('テスト用のサーフスポットです')).toBeInTheDocument();
    });
  });

  test('displays live camera section when cameras are available', async () => {
    renderWithRouter(<SpotDetail />);
    
    await waitFor(() => {
      expect(screen.getByText('ライブカメラ')).toBeInTheDocument();
      expect(screen.getByText('テストカメラ')).toBeInTheDocument();
    });
  });

  test('displays personalization prompt for non-logged in users', async () => {
    renderWithRouter(<SpotDetail />);
    
    await waitFor(() => {
      expect(screen.getByText(/パーソナライズされた波予測/)).toBeInTheDocument();
      expect(screen.getByText(/ログインして/)).toBeInTheDocument();
    });
  });
});
