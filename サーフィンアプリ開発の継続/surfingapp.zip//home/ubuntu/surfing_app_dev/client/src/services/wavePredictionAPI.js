import axios from 'axios';

/**
 * 波予測APIクライアント
 * 将来的に実際のAPIキーと接続情報で置き換える
 */
class WavePredictionAPI {
  constructor() {
    this.baseURL = process.env.REACT_APP_WAVE_API_URL || 'https://api.example.com/v1';
    this.apiKey = process.env.REACT_APP_WAVE_API_KEY || 'demo-key';
    
    this.client = axios.create({
      baseURL: this.baseURL,
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json'
      }
    });
  }

  /**
   * 指定された場所の波予測データを取得
   * @param {string} location - 場所の識別子（例: '千葉県-一宮海岸'）
   * @param {Object} params - 追加のパラメータ
   * @returns {Promise} 波予測データ
   */
  async getWaveForecast(location, params = {}) {
    try {
      // 実際のAPIが利用可能になるまでモックデータを返す
      return this.getMockWaveForecast(location);
      
      // 実際のAPI呼び出し（コメントアウト）
      // const response = await this.client.get(`/forecast/${encodeURIComponent(location)}`, { params });
      // return response.data;
    } catch (error) {
      console.error('波予測データの取得に失敗しました:', error);
      throw error;
    }
  }

  /**
   * モックの波予測データを生成
   * @param {string} location - 場所の識別子
   * @returns {Object} モックの波予測データ
   */
  getMockWaveForecast(location) {
    // 場所に基づいて異なるデータを返す
    const locationData = {
      '千葉県-一宮海岸': {
        waveHeight: 1.2, // メートル
        wavePeriod: 8,   // 秒
        windSpeed: 5,    // m/s
        windDirection: 'offshore', // 'offshore', 'onshore', 'cross-shore'
        tide: 'mid',     // 'low', 'mid', 'high'
        waterTemperature: 22, // 摂氏
      },
      '神奈川県-鎌倉材木座': {
        waveHeight: 0.8,
        wavePeriod: 6,
        windSpeed: 8,
        windDirection: 'cross-shore',
        tide: 'low',
        waterTemperature: 21,
      },
      '千葉県-志田下': {
        waveHeight: 1.8,
        wavePeriod: 10,
        windSpeed: 3,
        windDirection: 'offshore',
        tide: 'high',
        waterTemperature: 23,
      },
      // デフォルトデータ
      'default': {
        waveHeight: 1.0,
        wavePeriod: 7,
        windSpeed: 6,
        windDirection: 'cross-shore',
        tide: 'mid',
        waterTemperature: 22,
      }
    };

    // 指定された場所のデータがあればそれを返し、なければデフォルトを返す
    const data = locationData[location] || locationData['default'];
    
    // 予測データの配列を生成（今日から7日分）
    const forecast = [];
    const today = new Date();
    
    for (let i = 0; i < 7; i++) {
      const date = new Date(today);
      date.setDate(date.getDate() + i);
      
      // 日によって少し値を変動させる
      const dailyVariation = Math.sin(i * 0.5) * 0.3;
      
      forecast.push({
        date: date.toISOString().split('T')[0],
        waveHeight: Math.max(0.1, data.waveHeight + dailyVariation),
        wavePeriod: Math.max(4, data.wavePeriod + (dailyVariation * 2)),
        windSpeed: Math.max(0, data.windSpeed + (dailyVariation * 3)),
        windDirection: data.windDirection,
        tide: data.tide,
        waterTemperature: Math.max(15, data.waterTemperature + dailyVariation),
      });
    }
    
    return {
      location,
      forecast,
      lastUpdated: new Date().toISOString()
    };
  }
}

export default new WavePredictionAPI();
