import { useState, useEffect } from 'react';
import wavePredictionAPI from '../services/wavePredictionAPI';

/**
 * パーソナライズされたスコアリングアルゴリズム
 * ユーザーのスキルレベルとボードタイプに基づいて波のコンディションをスコアリング
 */
class ScoringAlgorithm {
  /**
   * スコアを計算
   * @param {Object} waveData - 波のデータ
   * @param {Object} userProfile - ユーザープロファイル
   * @returns {Object} スコア情報
   */
  calculateScore(waveData, userProfile) {
    // スキルレベルの重み付け
    const skillWeights = {
      'beginner': {
        idealWaveHeight: { min: 0.3, max: 1.0 },
        idealWindSpeed: { max: 5 },
        preferOffshore: true,
        idealWavePeriod: { min: 6, max: 10 }
      },
      'intermediate': {
        idealWaveHeight: { min: 0.5, max: 1.5 },
        idealWindSpeed: { max: 8 },
        preferOffshore: true,
        idealWavePeriod: { min: 8, max: 12 }
      },
      'advanced': {
        idealWaveHeight: { min: 0.8, max: 2.5 },
        idealWindSpeed: { max: 10 },
        preferOffshore: true,
        idealWavePeriod: { min: 10, max: 16 }
      }
    };

    // ボードタイプの重み付け
    const boardWeights = {
      'longboard': {
        waveHeightAdjustment: -0.2, // 小さい波に適している
        windToleranceAdjustment: 1.5, // 風の影響を受けにくい
      },
      'shortboard': {
        waveHeightAdjustment: 0.3, // より大きな波に適している
        windToleranceAdjustment: 0.8, // 風の影響を受けやすい
      },
      'fish': {
        waveHeightAdjustment: 0, // 中間的
        windToleranceAdjustment: 1.2, // 比較的風の影響を受けにくい
      },
      'funboard': {
        waveHeightAdjustment: -0.1, // やや小さい波に適している
        windToleranceAdjustment: 1.3, // 比較的風の影響を受けにくい
      }
    };

    // デフォルト値の設定
    const skill = userProfile?.skillLevel || 'intermediate';
    const boardType = userProfile?.boardType || 'shortboard';
    
    const skillWeight = skillWeights[skill] || skillWeights.intermediate;
    const boardWeight = boardWeights[boardType] || boardWeights.shortboard;
    
    // 波の高さのスコア (0-100)
    let waveHeightScore = 0;
    const adjustedIdealMin = skillWeight.idealWaveHeight.min + boardWeight.waveHeightAdjustment;
    const adjustedIdealMax = skillWeight.idealWaveHeight.max + boardWeight.waveHeightAdjustment;
    
    if (waveData.waveHeight < adjustedIdealMin) {
      // 理想より小さい場合
      waveHeightScore = 50 * (waveData.waveHeight / adjustedIdealMin);
    } else if (waveData.waveHeight <= adjustedIdealMax) {
      // 理想の範囲内
      const ratio = (waveData.waveHeight - adjustedIdealMin) / (adjustedIdealMax - adjustedIdealMin);
      waveHeightScore = 80 + (20 * (1 - Math.abs(0.5 - ratio) * 2));
    } else {
      // 理想より大きい場合
      waveHeightScore = 80 * Math.exp(-0.5 * (waveData.waveHeight - adjustedIdealMax));
    }
    
    // 風のスコア (0-100)
    let windScore = 0;
    const adjustedMaxWind = skillWeight.idealWindSpeed.max * boardWeight.windToleranceAdjustment;
    
    if (waveData.windSpeed <= adjustedMaxWind) {
      windScore = 100 * (1 - waveData.windSpeed / adjustedMaxWind);
    } else {
      windScore = 50 * Math.exp(-0.2 * (waveData.windSpeed - adjustedMaxWind));
    }
    
    // 風向きの補正
    if (waveData.windDirection === 'offshore' && skillWeight.preferOffshore) {
      windScore = Math.min(100, windScore * 1.3);
    } else if (waveData.windDirection === 'onshore') {
      windScore = windScore * 0.7;
    }
    
    // 波の周期のスコア (0-100)
    let periodScore = 0;
    if (waveData.wavePeriod < skillWeight.idealWavePeriod.min) {
      periodScore = 60 * (waveData.wavePeriod / skillWeight.idealWavePeriod.min);
    } else if (waveData.wavePeriod <= skillWeight.idealWavePeriod.max) {
      periodScore = 80 + 20 * (1 - Math.abs(
        (waveData.wavePeriod - skillWeight.idealWavePeriod.min) / 
        (skillWeight.idealWavePeriod.max - skillWeight.idealWavePeriod.min) - 0.5
      ) * 2);
    } else {
      periodScore = 80 * Math.exp(-0.1 * (waveData.wavePeriod - skillWeight.idealWavePeriod.max));
    }
    
    // 総合スコアの計算 (0-100)
    const totalScore = (waveHeightScore * 0.4) + (windScore * 0.4) + (periodScore * 0.2);
    
    // スコアを5段階に変換
    let rating;
    if (totalScore >= 85) {
      rating = 'Excellent';
    } else if (totalScore >= 70) {
      rating = 'Good';
    } else if (totalScore >= 50) {
      rating = 'Fair';
    } else if (totalScore >= 30) {
      rating = 'Poor';
    } else {
      rating = 'Bad';
    }
    
    return {
      score: Math.round(totalScore),
      rating,
      details: {
        waveHeightScore: Math.round(waveHeightScore),
        windScore: Math.round(windScore),
        periodScore: Math.round(periodScore)
      }
    };
  }
}

/**
 * パーソナライズされた波予測スコアを取得するためのカスタムフック
 * @param {string} location - 場所の識別子
 * @param {Object} userProfile - ユーザープロファイル
 * @returns {Object} 波予測スコア情報
 */
export const useWaveForecastScore = (location, userProfile) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [forecastData, setForecastData] = useState(null);
  const [scoreData, setScoreData] = useState(null);
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const data = await wavePredictionAPI.getWaveForecast(location);
        setForecastData(data);
        
        // スコアリングアルゴリズムを適用
        const scoringAlgorithm = new ScoringAlgorithm();
        const scoredForecast = data.forecast.map(dayData => ({
          ...dayData,
          score: scoringAlgorithm.calculateScore(dayData, userProfile)
        }));
        
        setScoreData({
          ...data,
          forecast: scoredForecast
        });
        
        setError(null);
      } catch (err) {
        console.error('波予測スコアの取得に失敗しました:', err);
        setError('波予測データの取得中にエラーが発生しました。');
      } finally {
        setLoading(false);
      }
    };
    
    if (location) {
      fetchData();
    }
  }, [location, userProfile]);
  
  return { loading, error, forecastData, scoreData };
};

export default ScoringAlgorithm;
