import { createClient } from '@supabase/supabase-js';

// 環境変数から値を取得（実際の実装では.envファイルから取得）
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL || 'https://your-supabase-url.supabase.co';
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY || 'your-supabase-anon-key';

// Supabaseクライアントの初期化
const supabase = createClient(supabaseUrl, supabaseAnonKey);

export default supabase;
