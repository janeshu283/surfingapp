import React, { useState, useEffect } from 'react';
import supabase from '../services/supabaseClient';

const Community = () => {
  const [posts, setPosts] = useState([]);
  const [newPost, setNewPost] = useState({ content: '', surf_spot_id: '', wave_height: '', wave_quality: 'Fair', crowd_level: 'moderate' });
  const [loading, setLoading] = useState(true);
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [user, setUser] = useState(null);
  const [spots, setSpots] = useState([]);

  // ユーザー情報とサーフスポット情報の取得
  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        // ユーザー情報の取得
        const { data: { user } } = await supabase.auth.getUser();
        setUser(user);

        // サーフスポット情報の取得
        const { data: spotsData, error: spotsError } = await supabase
          .from('surf_spots')
          .select('id, name, regions(name, prefecture)');
        
        if (spotsError) throw spotsError;
        setSpots(spotsData || []);

        // 投稿の取得
        await fetchPosts();
      } catch (error) {
        console.error('初期データ取得エラー:', error);
        setError('データの取得に失敗しました');
      } finally {
        setLoading(false);
      }
    };

    fetchInitialData();
  }, []);

  // 投稿の取得
  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select(`
          *,
          users:user_id (id, email),
          profiles:user_id (username, avatar_url),
          surf_spots:surf_spot_id (id, name, regions(name, prefecture))
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setPosts(data || []);
    } catch (error) {
      console.error('投稿取得エラー:', error);
      setError('投稿の取得に失敗しました');
    }
  };

  // 新規投稿の作成
  const handleSubmitPost = async (e) => {
    e.preventDefault();
    
    if (!user) {
      setError('投稿するにはログインが必要です');
      return;
    }
    
    if (!newPost.content || !newPost.surf_spot_id) {
      setError('内容とサーフスポットは必須です');
      return;
    }
    
    setPosting(true);
    setError(null);
    setSuccess(false);
    
    try {
      const { error } = await supabase
        .from('posts')
        .insert({
          user_id: user.id,
          surf_spot_id: newPost.surf_spot_id,
          content: newPost.content,
          wave_height: newPost.wave_height || null,
          wave_quality: newPost.wave_quality,
          crowd_level: newPost.crowd_level
        });
      
      if (error) throw error;
      
      // 投稿フォームのリセット
      setNewPost({ content: '', surf_spot_id: '', wave_height: '', wave_quality: 'Fair', crowd_level: 'moderate' });
      setSuccess(true);
      
      // 投稿一覧の再取得
      await fetchPosts();
    } catch (error) {
      console.error('投稿作成エラー:', error);
      setError('投稿の作成に失敗しました');
    } finally {
      setPosting(false);
    }
  };

  // 入力値の変更ハンドラ
  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewPost(prev => ({ ...prev, [name]: value }));
  };

  // 日付フォーマット用関数
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ja-JP', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return <div className="loading">読み込み中...</div>;
  }

  return (
    <div className="community-container">
      <h2>コミュニティ</h2>
      
      {error && (
        <div className="alert alert-danger">
          {error}
        </div>
      )}
      
      {success && (
        <div className="alert alert-success">
          投稿が完了しました
        </div>
      )}
      
      {user ? (
        <div className="post-form-container card">
          <h3>新規投稿</h3>
          <form onSubmit={handleSubmitPost}>
            <div className="form-group">
              <label htmlFor="surf_spot_id">サーフスポット</label>
              <select
                id="surf_spot_id"
                name="surf_spot_id"
                className="form-control"
                value={newPost.surf_spot_id}
                onChange={handleChange}
                required
              >
                <option value="">選択してください</option>
                {spots.map(spot => (
                  <option key={spot.id} value={spot.id}>
                    {spot.regions.prefecture} - {spot.regions.name} - {spot.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="form-group">
              <label htmlFor="content">内容</label>
              <textarea
                id="content"
                name="content"
                className="form-control"
                value={newPost.content}
                onChange={handleChange}
                rows="4"
                required
                placeholder="波の状況、混雑状況、その他の情報を共有しましょう"
              ></textarea>
            </div>
            
            <div className="form-row">
              <div className="form-group col">
                <label htmlFor="wave_height">波高 (m)</label>
                <input
                  type="number"
                  id="wave_height"
                  name="wave_height"
                  className="form-control"
                  value={newPost.wave_height}
                  onChange={handleChange}
                  step="0.1"
                  min="0"
                  max="10"
                  placeholder="例: 1.5"
                />
              </div>
              
              <div className="form-group col">
                <label htmlFor="wave_quality">波質</label>
                <select
                  id="wave_quality"
                  name="wave_quality"
                  className="form-control"
                  value={newPost.wave_quality}
                  onChange={handleChange}
                >
                  <option value="Excellent">Excellent</option>
                  <option value="Good">Good</option>
                  <option value="Fair">Fair</option>
                  <option value="Poor">Poor</option>
                  <option value="Bad">Bad</option>
                </select>
              </div>
              
              <div className="form-group col">
                <label htmlFor="crowd_level">混雑状況</label>
                <select
                  id="crowd_level"
                  name="crowd_level"
                  className="form-control"
                  value={newPost.crowd_level}
                  onChange={handleChange}
                >
                  <option value="empty">空いている</option>
                  <option value="few">少ない</option>
                  <option value="moderate">普通</option>
                  <option value="crowded">混雑</option>
                  <option value="very_crowded">非常に混雑</option>
                </select>
              </div>
            </div>
            
            <button
              type="submit"
              className="btn btn-primary"
              disabled={posting}
            >
              {posting ? '投稿中...' : '投稿する'}
            </button>
          </form>
        </div>
      ) : (
        <div className="login-prompt card">
          <p>投稿するには<a href="/login">ログイン</a>してください。</p>
        </div>
      )}
      
      <div className="posts-container">
        <h3>最新の投稿</h3>
        
        {posts.length > 0 ? (
          posts.map(post => (
            <div key={post.id} className="post-card card">
              <div className="post-header">
                <div className="post-user">
                  <strong>{post.profiles?.username || '匿名ユーザー'}</strong>
                </div>
                <div className="post-spot">
                  <a href={`/spots/${post.surf_spot_id}`}>
                    {post.surf_spots?.regions?.prefecture} - {post.surf_spots?.regions?.name} - {post.surf_spots?.name}
                  </a>
                </div>
                <div className="post-date">
                  {formatDate(post.created_at)}
                </div>
              </div>
              
              <div className="post-content">
                {post.content}
              </div>
              
              <div className="post-meta">
                {post.wave_height && (
                  <div className="post-meta-item">
                    <strong>波高:</strong> {post.wave_height}m
                  </div>
                )}
                
                {post.wave_quality && (
                  <div className="post-meta-item">
                    <strong>波質:</strong> {post.wave_quality}
                  </div>
                )}
                
                {post.crowd_level && (
                  <div className="post-meta-item">
                    <strong>混雑:</strong> {
                      post.crowd_level === 'empty' ? '空いている' :
                      post.crowd_level === 'few' ? '少ない' :
                      post.crowd_level === 'moderate' ? '普通' :
                      post.crowd_level === 'crowded' ? '混雑' :
                      post.crowd_level === 'very_crowded' ? '非常に混雑' : post.crowd_level
                    }
                  </div>
                )}
              </div>
            </div>
          ))
        ) : (
          <p>投稿がありません</p>
        )}
      </div>
    </div>
  );
};

export default Community;
