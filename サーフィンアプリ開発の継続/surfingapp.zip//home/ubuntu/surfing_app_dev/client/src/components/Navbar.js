import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import supabase from '../services/supabaseClient';

const Navbar = () => {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);

  useEffect(() => {
    // ユーザーの認証状態を取得
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
    };

    getUser();

    // 認証状態の変更を監視
    const { data: authListener } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user || null);
      }
    );

    return () => {
      if (authListener && authListener.subscription) {
        authListener.subscription.unsubscribe();
      }
    };
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  return (
    <nav className="navbar">
      <div className="container navbar-container">
        <Link to="/" className="navbar-logo">
          サーフィンアプリ
        </Link>
        <div className="navbar-links">
          <Link to="/spots" className="navbar-link">
            サーフスポット
          </Link>
          <Link to="/community" className="navbar-link">
            コミュニティ
          </Link>
          {user ? (
            <>
              <Link to="/profile" className="navbar-link">
                プロフィール
              </Link>
              <button onClick={handleLogout} className="btn btn-secondary navbar-btn">
                ログアウト
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="navbar-link">
                ログイン
              </Link>
              <Link to="/register" className="btn btn-secondary navbar-btn">
                新規登録
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
