import React from 'react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3>サーフィンアプリ</h3>
            <p>日本のサーファーのための波情報プラットフォーム</p>
          </div>
          <div className="footer-section">
            <h3>リンク</h3>
            <ul className="footer-links">
              <li><a href="/">ホーム</a></li>
              <li><a href="/spots">サーフスポット</a></li>
              <li><a href="/login">ログイン</a></li>
              <li><a href="/register">新規登録</a></li>
            </ul>
          </div>
          <div className="footer-section">
            <h3>お問い合わせ</h3>
            <p>ご質問やフィードバックがありましたら、お気軽にお問い合わせください。</p>
            <a href="mailto:info@surfingapp.jp">info@surfingapp.jp</a>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; {currentYear} サーフィンアプリ. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
