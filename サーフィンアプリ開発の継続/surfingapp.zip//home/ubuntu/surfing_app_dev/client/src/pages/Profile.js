import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import supabase from '../services/supabaseClient';

const Profile = () => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState({
    username: '',
    skill_level: 'beginner',
    board_type: 'shortboard',
    board_length: '',
    preferred_style: ''
  });
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  // ユーザー情報の取得
  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        navigate('/login');
        return;
      }
      
      setUser(user);
      
      try {
        // プロフィール情報の取得
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
        
        if (error && error.code !== 'PGRST116') {
          throw error;
        }
        
        if (data) {
          setProfile(data);
        }
      } catch (error) {
        console.error('プロフィール取得エラー:', error);
        setError('プロフィールの取得に失敗しました');
      } finally {
        setLoading(false);
      }
    };
    
    getUser();
  }, [navigate]);

  // プロフィール更新
  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setUpdating(true);
    setError(null);
    setSuccess(false);
    
    try {
      if (!user) throw new Error('ユーザーが認証されていません');
      
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: user.id,
          username: profile.username,
          skill_level: profile.skill_level,
          board_type: profile.board_type,
          board_length: profile.board_length || null,
          preferred_style: profile.preferred_style || null,
          updated_at: new Date()
        });
      
      if (error) throw error;
      
      setSuccess(true);
    } catch (error) {
      console.error('プロフィール更新エラー:', error);
      setError('プロフィールの更新に失敗しました');
    } finally {
      setUpdating(false);
    }
  };

  // 入力値の変更ハンドラ
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({ ...prev, [name]: value }));
  };

  if (loading) {
    return <div className="loading">読み込み中...</div>;
  }

  return (
    <div className="profile-container">
      <h2>プロフィール設定</h2>
      
      {error && (
        <div className="alert alert-danger">
          {error}
        </div>
      )}
      
      {success && (
        <div className="alert alert-success">
          プロフィールが更新されました
        </div>
      )}
      
      <div className="card">
        <form onSubmit={handleUpdateProfile}>
          <div className="form-group">
            <label htmlFor="username">ユーザー名</label>
            <input
              type="text"
              id="username"
              name="username"
              className="form-control"
              value={profile.username}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="skill_level">スキルレベル</label>
            <select
              id="skill_level"
              name="skill_level"
              className="form-control"
              value={profile.skill_level}
              onChange={handleChange}
              required
            >
              <option value="beginner">初心者</option>
              <option value="intermediate">中級者</option>
              <option value="advanced">上級者</option>
            </select>
          </div>
          
          <div className="form-group">
            <label htmlFor="board_type">ボードタイプ</label>
            <select
              id="board_type"
              name="board_type"
              className="form-control"
              value={profile.board_type}
              onChange={handleChange}
              required
            >
              <option value="shortboard">ショートボード</option>
              <option value="longboard">ロングボード</option>
              <option value="funboard">ファンボード</option>
              <option value="fish">フィッシュ</option>
              <option value="sup">SUP</option>
            </select>
          </div>
          
          <div className="form-group">
            <label htmlFor="board_length">ボード長さ（フィート）</label>
            <input
              type="number"
              id="board_length"
              name="board_length"
              className="form-control"
              value={profile.board_length || ''}
              onChange={handleChange}
              step="0.1"
              min="4"
              max="12"
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="preferred_style">好みのスタイル</label>
            <input
              type="text"
              id="preferred_style"
              name="preferred_style"
              className="form-control"
              value={profile.preferred_style || ''}
              onChange={handleChange}
              placeholder="例: パワーサーフィン、ノーズライディングなど"
            />
          </div>
          
          <button
            type="submit"
            className="btn btn-primary"
            disabled={updating}
          >
            {updating ? '更新中...' : 'プロフィールを更新'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Profile;
