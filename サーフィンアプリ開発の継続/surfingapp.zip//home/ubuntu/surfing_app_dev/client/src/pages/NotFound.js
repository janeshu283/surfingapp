import React from 'react';

const NotFound = () => {
  return (
    <div className="not-found-container text-center">
      <h2>404 - ページが見つかりません</h2>
      <p>お探しのページは存在しないか、移動した可能性があります。</p>
      <a href="/" className="btn btn-primary mt-3">
        ホームに戻る
      </a>
    </div>
  );
};

export default NotFound;
