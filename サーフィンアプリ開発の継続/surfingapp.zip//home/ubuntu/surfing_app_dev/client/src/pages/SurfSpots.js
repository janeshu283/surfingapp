import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import supabase from '../services/supabaseClient';

const SurfSpots = () => {
  const [spots, setSpots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [regions, setRegions] = useState([]);

  useEffect(() => {
    const fetchSpots = async () => {
      try {
        // サーフスポットの取得
        let query = supabase.from('surf_spots').select('*, regions(*)');
        
        if (selectedRegion !== 'all') {
          query = query.eq('region_id', selectedRegion);
        }
        
        const { data, error } = await query;
        
        if (error) throw error;
        
        setSpots(data || []);
        
        // 地域の取得
        const { data: regionsData, error: regionsError } = await supabase
          .from('regions')
          .select('*');
        
        if (regionsError) throw regionsError;
        
        setRegions(regionsData || []);
      } catch (error) {
        console.error('サーフスポット取得エラー:', error);
        setError('サーフスポットの取得に失敗しました');
      } finally {
        setLoading(false);
      }
    };
    
    fetchSpots();
  }, [selectedRegion]);

  const handleRegionChange = (e) => {
    setSelectedRegion(e.target.value);
  };

  if (loading) {
    return <div className="loading">読み込み中...</div>;
  }

  return (
    <div className="surf-spots-container">
      <h2>サーフスポット一覧</h2>
      
      {error && (
        <div className="alert alert-danger">
          {error}
        </div>
      )}
      
      <div className="filter-container mb-3">
        <label htmlFor="region-filter">地域で絞り込み:</label>
        <select
          id="region-filter"
          className="form-control"
          value={selectedRegion}
          onChange={handleRegionChange}
        >
          <option value="all">すべての地域</option>
          {regions.map(region => (
            <option key={region.id} value={region.id}>
              {region.prefecture} - {region.name}
            </option>
          ))}
        </select>
      </div>
      
      <div className="grid">
        {spots.length > 0 ? (
          spots.map(spot => (
            <div key={spot.id} className="card spot-card">
              <h3>{spot.name}</h3>
              <p className="region-name">{spot.regions?.prefecture} - {spot.regions?.name}</p>
              <p className="difficulty">
                難易度: {
                  spot.difficulty === 'beginner' ? '初心者向け' :
                  spot.difficulty === 'intermediate' ? '中級者向け' :
                  spot.difficulty === 'advanced' ? '上級者向け' : '全レベル'
                }
              </p>
              <p className="description">{spot.description}</p>
              <Link to={`/spots/${spot.id}`} className="btn">
                詳細を見る
              </Link>
            </div>
          ))
        ) : (
          <p>該当するサーフスポットがありません</p>
        )}
      </div>
    </div>
  );
};

export default SurfSpots;
