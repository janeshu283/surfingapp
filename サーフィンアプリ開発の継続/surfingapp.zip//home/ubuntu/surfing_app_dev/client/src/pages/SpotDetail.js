import React, { useState, useEffect } from 'react';
import { useWaveForecastScore } from '../services/scoringAlgorithm';

const SpotDetail = ({ match, userProfile }) => {
  // 実際のアプリではルーティングからスポットIDを取得
  const spotId = match?.params?.id || '千葉県-一宮海岸';
  
  // サンプルユーザープロファイル（実際のアプリではコンテキストやReduxから取得）
  const sampleUserProfile = userProfile || {
    skillLevel: 'intermediate',
    boardType: 'shortboard'
  };
  
  // 波予測スコアを取得
  const { loading, error, scoreData } = useWaveForecastScore(spotId, sampleUserProfile);
  
  // 選択された日付のインデックス（デフォルトは今日）
  const [selectedDayIndex, setSelectedDayIndex] = useState(0);
  
  if (loading) return <div className="p-4 text-center">読み込み中...</div>;
  if (error) return <div className="p-4 text-center text-danger">{error}</div>;
  if (!scoreData) return <div className="p-4 text-center">データがありません</div>;
  
  const selectedDay = scoreData.forecast[selectedDayIndex];
  
  // スコアに基づく背景色クラスを取得
  const getScoreColorClass = (rating) => {
    switch(rating) {
      case 'Excellent': return 'bg-success text-white';
      case 'Good': return 'bg-info text-white';
      case 'Fair': return 'bg-warning';
      case 'Poor': return 'bg-orange text-white';
      case 'Bad': return 'bg-danger text-white';
      default: return 'bg-secondary text-white';
    }
  };
  
  // 日付をフォーマット
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ja-JP', { month: 'short', day: 'numeric', weekday: 'short' });
  };
  
  return (
    <div className="container py-4">
      <h2 className="mb-4">{spotId}</h2>
      
      {/* 日付選択タブ */}
      <div className="nav nav-tabs mb-4">
        {scoreData.forecast.map((day, index) => (
          <button
            key={day.date}
            className={`nav-link ${index === selectedDayIndex ? 'active' : ''}`}
            onClick={() => setSelectedDayIndex(index)}
          >
            {formatDate(day.date)}
          </button>
        ))}
      </div>
      
      {/* 選択された日のスコア表示 */}
      <div className="row mb-4">
        <div className="col-md-6">
          <div className="card h-100">
            <div className="card-body">
              <h4 className="card-title">あなたにとってのスコア</h4>
              <div className="d-flex align-items-center mb-3">
                <div className={`score-badge p-3 rounded-3 me-3 ${getScoreColorClass(selectedDay.score.rating)}`}>
                  <h2 className="mb-0">{selectedDay.score.rating}</h2>
                </div>
                <div>
                  <p className="mb-0">スコア: {selectedDay.score.score}/100</p>
                  <p className="text-muted small mb-0">
                    スキルレベル: {sampleUserProfile.skillLevel}, 
                    ボードタイプ: {sampleUserProfile.boardType}
                  </p>
                </div>
              </div>
              
              {/* スコア詳細 */}
              <h5 className="mt-4">スコア詳細</h5>
              <div className="progress mb-2">
                <div 
                  className="progress-bar bg-primary" 
                  role="progressbar" 
                  style={{ width: `${selectedDay.score.details.waveHeightScore}%` }}
                  aria-valuenow={selectedDay.score.details.waveHeightScore} 
                  aria-valuemin="0" 
                  aria-valuemax="100"
                >
                  波の高さ: {selectedDay.score.details.waveHeightScore}
                </div>
              </div>
              <div className="progress mb-2">
                <div 
                  className="progress-bar bg-success" 
                  role="progressbar" 
                  style={{ width: `${selectedDay.score.details.windScore}%` }}
                  aria-valuenow={selectedDay.score.details.windScore} 
                  aria-valuemin="0" 
                  aria-valuemax="100"
                >
                  風: {selectedDay.score.details.windScore}
                </div>
              </div>
              <div className="progress mb-2">
                <div 
                  className="progress-bar bg-info" 
                  role="progressbar" 
                  style={{ width: `${selectedDay.score.details.periodScore}%` }}
                  aria-valuenow={selectedDay.score.details.periodScore} 
                  aria-valuemin="0" 
                  aria-valuemax="100"
                >
                  波の周期: {selectedDay.score.details.periodScore}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="col-md-6">
          <div className="card h-100">
            <div className="card-body">
              <h4 className="card-title">波の状況</h4>
              <div className="row">
                <div className="col-6 mb-3">
                  <p className="text-muted mb-0">波の高さ</p>
                  <h5>{selectedDay.waveHeight}m</h5>
                </div>
                <div className="col-6 mb-3">
                  <p className="text-muted mb-0">波の周期</p>
                  <h5>{selectedDay.wavePeriod}秒</h5>
                </div>
                <div className="col-6 mb-3">
                  <p className="text-muted mb-0">風速</p>
                  <h5>{selectedDay.windSpeed}m/s</h5>
                </div>
                <div className="col-6 mb-3">
                  <p className="text-muted mb-0">風向き</p>
                  <h5>
                    {selectedDay.windDirection === 'offshore' ? 'オフショア' : 
                     selectedDay.windDirection === 'onshore' ? 'オンショア' : 'サイドショア'}
                  </h5>
                </div>
                <div className="col-6 mb-3">
                  <p className="text-muted mb-0">潮</p>
                  <h5>
                    {selectedDay.tide === 'low' ? '干潮' : 
                     selectedDay.tide === 'high' ? '満潮' : '中潮'}
                  </h5>
                </div>
                <div className="col-6 mb-3">
                  <p className="text-muted mb-0">水温</p>
                  <h5>{selectedDay.waterTemperature}°C</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* ライブカメラセクション */}
      <div className="card mb-4">
        <div className="card-body">
          <h4 className="card-title">ライブカメラ</h4>
          <div className="ratio ratio-16x9">
            {/* 実際のアプリでは、スポットに応じた実際のYouTube埋め込みURLを使用 */}
            <iframe 
              src="https://www.youtube.com/embed/dQw4w9WgXcQ" 
              title="ライブカメラ" 
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>
      
      {/* コミュニティ投稿セクション */}
      <div className="card">
        <div className="card-body">
          <h4 className="card-title">最新の投稿</h4>
          <div className="mb-3">
            <div className="d-flex align-items-center mb-2">
              <img src="https://randomuser.me/api/portraits/men/32.jpg" className="rounded-circle me-2" width="40" height="40" alt="ユーザーアイコン" />
              <div>
                <h6 className="mb-0">田中サーファー</h6>
                <p className="text-muted small mb-0">2時間前</p>
              </div>
            </div>
            <p>今日の一宮は腰〜腹。風は弱く、コンディション良好でした！人も少なめで最高のセッションでした。</p>
            <div>
              <span className="badge bg-primary me-2">波高: 腰〜腹</span>
              <span className="badge bg-success">混雑: 少なめ</span>
            </div>
          </div>
          
          <hr />
          
          <div>
            <div className="d-flex align-items-center mb-2">
              <img src="https://randomuser.me/api/portraits/women/44.jpg" className="rounded-circle me-2" width="40" height="40" alt="ユーザーアイコン" />
              <div>
                <h6 className="mb-0">サーフガール</h6>
                <p className="text-muted small mb-0">昨日</p>
              </div>
            </div>
            <p>朝イチは良かったけど、9時頃から風が強くなってきました。明日の方が良さそう。</p>
            <div>
              <span className="badge bg-warning text-dark me-2">波高: 膝〜腰</span>
              <span className="badge bg-warning text-dark">混雑: 普通</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SpotDetail;
