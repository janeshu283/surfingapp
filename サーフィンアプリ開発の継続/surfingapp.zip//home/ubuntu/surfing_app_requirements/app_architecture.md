# サーフィンアプリ アーキテクチャ設計書

## 1. システム概要

### 1.1 アーキテクチャの目的
本アーキテクチャは、日本のサーファー向けパーソナライズされたコミュニティ主導型サーフィンアプリのMVP（Minimum Viable Product）開発のための技術的基盤を定義するものです。ウェブアプリケーションとして開発し、PMF（Product Market Fit）確認後にiOS/Androidアプリ開発に着手することを前提としています。

### 1.2 アーキテクチャの原則
- **スケーラビリティ**: ユーザー数の増加に対応できる設計
- **モジュール性**: 機能ごとの独立した開発と拡張が可能な構造
- **保守性**: コードの可読性と保守性を重視
- **セキュリティ**: ユーザーデータの保護を最優先
- **パフォーマンス**: 応答性の高いユーザー体験の提供
- **拡張性**: 将来的な機能追加や技術変更に対応できる柔軟性

### 1.3 技術スタック概要
- **フロントエンド**: React.js
- **バックエンド**: Node.js
- **データベース**: Supabase (PostgreSQL)
- **認証**: Supabase Auth
- **ストレージ**: Supabase Storage
- **ホスティング**: Vercel/Netlify
- **開発ツール**: AI コーディングツール (Windsurf)

## 2. システムアーキテクチャ

### 2.1 全体アーキテクチャ図

```
+----------------------------------+
|           クライアント層           |
|  +----------------------------+  |
|  |        React.js App        |  |
|  | (SPA with PWA capabilities)|  |
|  +----------------------------+  |
+----------------------------------+
              |
              | HTTPS
              v
+----------------------------------+
|           サーバー層              |
|  +----------------------------+  |
|  |        Node.js API         |  |
|  | (Express.js REST API)      |  |
|  +----------------------------+  |
+----------------------------------+
              |
              | SQL/REST
              v
+----------------------------------+
|          データ層                |
|  +----------------------------+  |
|  |         Supabase           |  |
|  | (PostgreSQL + Auth + Storage)|
|  +----------------------------+  |
+----------------------------------+
              |
              v
+----------------------------------+
|         外部サービス層            |
|  +------------+  +------------+  |
|  | 気象API    |  | YouTube API|  |
|  +------------+  +------------+  |
|  +------------+  +------------+  |
|  | 決済サービス|  | Amazon API |  |
|  +------------+  +------------+  |
+----------------------------------+
```

### 2.2 アーキテクチャパターン
- **クライアントサイド**: シングルページアプリケーション（SPA）
- **サーバーサイド**: RESTful APIアーキテクチャ
- **データアクセス**: リポジトリパターン
- **状態管理**: Flux/Reduxパターン（クライアント）
- **認証**: トークンベース認証（JWT）

## 3. コンポーネント設計

### 3.1 フロントエンドコンポーネント

#### 3.1.1 コアコンポーネント
- **App**: アプリケーションのルートコンポーネント
- **Router**: ルーティング管理
- **AuthProvider**: 認証状態管理
- **ThemeProvider**: テーマ管理
- **ErrorBoundary**: エラーハンドリング

#### 3.1.2 機能コンポーネント
- **UserManagement**: ユーザー管理関連コンポーネント
  - ProfileEditor
  - SubscriptionManager
  - SettingsPanel
- **WaveForecast**: 波予測関連コンポーネント
  - ForecastDashboard
  - WaveDetails
  - PersonalizedScore
  - SpotRecommendation
- **LiveCamera**: ライブカメラ関連コンポーネント
  - CameraViewer
  - TimelapsePlayer
  - AIAnalysisDisplay
- **Community**: コミュニティ関連コンポーネント
  - PostCreator
  - Feed
  - CommentSystem
  - PointsDisplay
- **RegionalInfo**: 地域情報関連コンポーネント
  - RegionSelector
  - RegionDetails
  - RegionComparison
- **AIFeatures**: AI機能関連コンポーネント
  - PersonalizationEngine
  - ImageRecognition
  - PredictionAnalysis
- **DataAnalytics**: データ分析関連コンポーネント
  - WaveStatistics
  - ActivityTracker
  - CommunityAnalytics

#### 3.1.3 共通UIコンポーネント
- **Navigation**: ナビゲーションバー、メニュー
- **Cards**: 情報カード、リストアイテム
- **Forms**: 入力フォーム、バリデーション
- **Modals**: モーダルダイアログ
- **Notifications**: 通知、アラート
- **Maps**: 地図表示、位置情報
- **Charts**: グラフ、データ可視化
- **MediaViewer**: 画像、動画表示

### 3.2 バックエンドコンポーネント

#### 3.2.1 APIレイヤー
- **AuthController**: 認証・認可管理
- **UserController**: ユーザー情報管理
- **ForecastController**: 波予測データ管理
- **CameraController**: ライブカメラ統合
- **PostController**: ユーザー投稿管理
- **PointController**: ポイント制度管理
- **RegionController**: 地域情報管理
- **SubscriptionController**: サブスクリプション管理
- **AnalyticsController**: データ分析・レポート

#### 3.2.2 サービスレイヤー
- **AuthService**: 認証ロジック
- **UserService**: ユーザー管理ロジック
- **ForecastService**: 波予測ロジック
- **AIService**: AI機能ロジック
- **CameraService**: カメラ統合ロジック
- **CommunityService**: コミュニティ機能ロジック
- **PointService**: ポイント計算ロジック
- **NotificationService**: 通知管理ロジック
- **ExternalAPIService**: 外部API連携ロジック

#### 3.2.3 データアクセスレイヤー
- **UserRepository**: ユーザーデータアクセス
- **ForecastRepository**: 波予測データアクセス
- **PostRepository**: 投稿データアクセス
- **PointRepository**: ポイントデータアクセス
- **RegionRepository**: 地域データアクセス
- **SubscriptionRepository**: サブスクリプションデータアクセス
- **AnalyticsRepository**: 分析データアクセス

### 3.3 データモデル

#### 3.3.1 ユーザー関連
- **User**: ユーザー基本情報
  - id: UUID
  - email: string
  - password_hash: string
  - nickname: string
  - profile_image_url: string
  - created_at: timestamp
  - updated_at: timestamp

- **UserProfile**: ユーザープロフィール詳細
  - user_id: UUID (FK)
  - skill_level: enum (beginner, intermediate, advanced)
  - experience_years: number
  - board_type: enum (shortboard, funboard, longboard, etc)
  - board_length: number
  - surf_style: string
  - favorite_spots: string[]
  - bio: text
  - privacy_settings: jsonb

- **UserSubscription**: サブスクリプション情報
  - user_id: UUID (FK)
  - plan_id: UUID (FK)
  - status: enum (active, canceled, expired)
  - start_date: timestamp
  - end_date: timestamp
  - payment_method: jsonb
  - auto_renew: boolean

#### 3.3.2 波予測関連
- **SurfSpot**: サーフポイント情報
  - id: UUID
  - name: string
  - region_id: UUID (FK)
  - latitude: number
  - longitude: number
  - description: text
  - characteristics: jsonb
  - local_rules: text
  - facilities: jsonb
  - created_at: timestamp
  - updated_at: timestamp

- **WaveForecast**: 波予測データ
  - id: UUID
  - spot_id: UUID (FK)
  - forecast_time: timestamp
  - wave_height: number
  - wave_period: number
  - wave_direction: number
  - wind_speed: number
  - wind_direction: number
  - tide_height: number
  - tide_type: enum (rising, falling)
  - quality_score: number
  - source: string
  - created_at: timestamp

- **PersonalizedScore**: パーソナライズされたスコア
  - user_id: UUID (FK)
  - forecast_id: UUID (FK)
  - score: number
  - factors: jsonb
  - created_at: timestamp

#### 3.3.3 コミュニティ関連
- **Post**: ユーザー投稿
  - id: UUID
  - user_id: UUID (FK)
  - spot_id: UUID (FK)
  - content: text
  - media_urls: string[]
  - wave_height: number
  - wave_quality: enum (poor, fair, good, excellent)
  - crowd_level: enum (empty, uncrowded, moderate, crowded)
  - tags: string[]
  - created_at: timestamp
  - updated_at: timestamp

- **Comment**: コメント
  - id: UUID
  - post_id: UUID (FK)
  - user_id: UUID (FK)
  - content: text
  - created_at: timestamp
  - updated_at: timestamp

- **UserPoint**: ユーザーポイント
  - user_id: UUID (FK)
  - total_points: number
  - available_points: number
  - last_updated: timestamp

- **PointTransaction**: ポイント取引
  - id: UUID
  - user_id: UUID (FK)
  - amount: number
  - type: enum (earned, redeemed)
  - source: string
  - reference_id: UUID
  - created_at: timestamp

#### 3.3.4 その他
- **Region**: 地域情報
  - id: UUID
  - name: string
  - prefecture: string
  - description: text
  - characteristics: jsonb
  - created_at: timestamp
  - updated_at: timestamp

- **LiveCamera**: ライブカメラ情報
  - id: UUID
  - spot_id: UUID (FK)
  - name: string
  - url: string
  - source: string
  - status: enum (active, inactive)
  - last_checked: timestamp

- **SubscriptionPlan**: サブスクリプションプラン
  - id: UUID
  - name: string
  - description: text
  - price: number
  - duration: enum (monthly, yearly)
  - features: jsonb
  - is_active: boolean
  - created_at: timestamp
  - updated_at: timestamp

## 4. データフロー

### 4.1 パーソナライズされた波予測フロー
1. ユーザーがアプリにログイン
2. フロントエンドがユーザープロフィール情報をロード
3. フロントエンドが選択された地域の波予測データをリクエスト
4. バックエンドが外部気象APIから最新データを取得（キャッシュ済みでなければ）
5. バックエンドがユーザープロフィールに基づいてパーソナライズスコアを計算
6. フロントエンドがパーソナライズされた波予測を表示
7. ユーザーがフィードバックを提供（実際の波との差異など）
8. バックエンドがフィードバックをAIモデルに取り込み、将来の予測精度を向上

### 4.2 ユーザー投稿フロー
1. ユーザーが波情報を投稿（写真、コメント、評価など）
2. フロントエンドが投稿データをバックエンドに送信
3. バックエンドが投稿を検証し、データベースに保存
4. バックエンドがポイント計算ロジックを実行
5. ユーザーにポイント付与の通知を送信
6. 投稿がコミュニティフィードに表示される
7. 他のユーザーが投稿にいいね・コメントできる
8. 投稿データがAI分析に使用され、波予測の精度向上に貢献

### 4.3 ポイント交換フロー
1. ユーザーがポイント交換ページにアクセス
2. 利用可能なポイント残高と交換可能アイテムが表示される
3. ユーザーがAmazonギフト券との交換を選択
4. バックエンドが交換リクエストを検証
5. バックエンドがAmazon APIと連携してギフト券コードを生成
6. ユーザーにギフト券コードが提供される
7. ポイント残高が更新される
8. 交換履歴がデータベースに記録される

## 5. セキュリティ設計

### 5.1 認証・認可
- **認証方式**: JWT（JSON Web Token）ベースの認証
- **ソーシャルログイン**: Google、Apple、Twitterとの連携
- **多要素認証**: オプションで提供
- **アクセス制御**: ロールベースのアクセス制御（RBAC）
- **トークン管理**: アクセストークンと更新トークンの分離

### 5.2 データ保護
- **保存データ暗号化**: 個人情報の暗号化
- **通信暗号化**: TLS 1.3による通信の暗号化
- **決済情報**: PCI DSS準拠の決済処理
- **データバックアップ**: 定期的な暗号化バックアップ
- **データ保持ポリシー**: 明確なデータ保持期間の設定

### 5.3 脆弱性対策
- **入力検証**: すべてのユーザー入力の検証
- **XSS対策**: コンテンツセキュリティポリシー（CSP）の実装
- **CSRF対策**: アンチCSRFトークンの使用
- **SQLインジェクション対策**: パラメータ化クエリの使用
- **レート制限**: API呼び出しの制限
- **セキュリティヘッダー**: 適切なセキュリティヘッダーの設定

## 6. スケーラビリティ設計

### 6.1 水平スケーリング
- **ステートレスAPI**: セッション状態を持たないAPI設計
- **ロードバランシング**: 複数インスタンス間の負荷分散
- **コンテナ化**: Dockerコンテナによるデプロイ
- **オートスケーリング**: 負荷に応じた自動スケーリング

### 6.2 データベーススケーリング
- **接続プーリング**: データベース接続の効率的管理
- **インデックス最適化**: クエリパフォーマンスの向上
- **読み取りレプリケーション**: 読み取り負荷の分散
- **シャーディング準備**: 将来的なデータ分割の準備

### 6.3 キャッシュ戦略
- **アプリケーションキャッシュ**: 頻繁にアクセスされるデータのキャッシュ
- **CDN**: 静的アセットのキャッシュ
- **波予測データキャッシュ**: 短期間有効な予測データのキャッシュ
- **ユーザーセッションキャッシュ**: アクティブセッションの高速アクセス

## 7. 外部システム連携

### 7.1 気象データAPI
- **連携方式**: RESTful API
- **データ取得頻度**: 1時間ごと
- **フォールバック戦略**: 複数のデータソースの利用
- **データ変換**: 標準フォーマットへの変換処理

### 7.2 YouTubeライブカメラ
- **連携方式**: YouTube Data API
- **埋め込み方法**: iframeによる埋め込み
- **更新確認**: 定期的な可用性チェック
- **代替表示**: カメラ停止時の代替コンテンツ

### 7.3 決済システム
- **連携方式**: 決済プロバイダーAPI
- **サポート決済方法**: クレジットカード、Apple Pay、Google Pay
- **サブスクリプション管理**: 自動更新、キャンセル処理
- **セキュリティ**: PCI DSS準拠の処理

### 7.4 Amazonギフト券API
- **連携方式**: Amazon Gift Card API
- **コード生成**: ギフト券コードの自動生成
- **検証プロセス**: コード有効性の確認
- **エラーハンドリング**: 生成失敗時の対応

## 8. デプロイメント戦略

### 8.1 環境構成
- **開発環境**: ローカル開発環境
- **テスト環境**: CI/CD連携のテスト環境
- **ステージング環境**: 本番に近い構成のステージング
- **本番環境**: 実ユーザー向け環境

### 8.2 CI/CD
- **コード管理**: GitHubリポジトリ
- **CI**: GitHub Actions
- **テスト自動化**: 単体テスト、統合テスト、E2Eテスト
- **デプロイ自動化**: 自動デプロイパイプライン
- **ロールバック**: 問題発生時の自動ロールバック

### 8.3 モニタリング
- **アプリケーションモニタリング**: パフォーマンス、エラー監視
- **サーバーモニタリング**: リソース使用率、可用性
- **ログ管理**: 集中ログ収集と分析
- **アラート**: 異常検知と通知
- **ユーザーフィードバック**: 問題報告の収集

## 9. MVPフェーズと将来拡張

### 9.1 MVPスコープ
- **コア機能**: パーソナライズされた波予測、ライブカメラ統合、基本的なユーザー投稿
- **対象プラットフォーム**: ウェブアプリケーション（モバイルレスポンシブ）
- **対象地域**: 日本の主要サーフポイント
- **収益モデル**: 基本的なフリーミアムモデル

### 9.2 将来拡張
- **ネイティブアプリ**: iOS/Androidネイティブアプリ開発
- **AIの高度化**: 機械学習モデルの継続的改善
- **地域拡大**: 海外サーフポイントへの拡張
- **ソーシャル機能**: 高度なコミュニティ機能
- **ウェアラブル連携**: スマートウォッチなどとの連携
- **サーフィン関連サービス**: サーフショップ、レッスン、宿泊施設との連携

## 10. 技術的リスクと対策

### 10.1 データ精度リスク
- **リスク**: 波予測データの精度不足
- **対策**: 
  - 複数のデータソースの統合
  - ユーザーフィードバックによる継続的改善
  - AIモデルの定期的な再トレーニング

### 10.2 スケーラビリティリスク
- **リスク**: ユーザー増加時のパフォーマンス低下
- **対策**:
  - 初期段階からのスケーラブルなアーキテクチャ設計
  - 負荷テストの定期実施
  - クラウドリソースの柔軟な調整

### 10.3 外部依存リスク
- **リスク**: 外部APIの可用性や変更による影響
- **対策**:
  - フォールバックメカニズムの実装
  - 依存関係の最小化
  - API変更の監視と迅速な対応

### 10.4 セキュリティリスク
- **リスク**: ユーザーデータの漏洩や不正アクセス
- **対策**:
  - 定期的なセキュリティ監査
  - 脆弱性スキャンの実施
  - セキュリティベストプラクティスの遵守
